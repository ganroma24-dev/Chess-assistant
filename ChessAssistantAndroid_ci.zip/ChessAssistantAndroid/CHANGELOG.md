# Changelog

## 0.3.0
- Added a checkerboard-pattern board-boundary detector inside the user-calibrated MediaProjection region; axis-aligned square crops are extracted without saving screenshots.
- Added a TensorFlow Lite 13-class square recognizer contract, batched 64-square inference, stable-frame gating, and a training/export script. A trained `piece_classifier.tflite` is not bundled.
- Added legal move generation, check detection, castling, en-passant, promotion, SAN resolution, and board-diff move tracking.
- Added PGN main-line replay with legal-move validation and previous/next navigation.
- Added a manual, bounded Stockfish UCI analysis action for the current study FEN, including score extraction and timeout handling.
- Added smoke/unit tests for opening moves, SAN, PGN replay, move tracking, castling, en-passant, promotion, and a fake-engine UCI handshake check.

## 0.2.0
- Added FEN position editor, PGN token extraction, and a minimal UCI bridge.
- Added privacy-preserving frame sampling and board region calibration.
