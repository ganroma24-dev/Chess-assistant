package com.example.chessassistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class ChessPositionTest {
    @Test fun startPositionRoundTrips() {
        assertEquals(ChessPosition.START_FEN, ChessPosition.fromFen(ChessPosition.START_FEN).toFen())
    }

    @Test fun pieceEditingUsesAlgebraicSquares() {
        val position = ChessPosition.fromFen(ChessPosition.START_FEN).withPiece("e4", 'Q')
        assertEquals('Q', position["e4"])
        assertEquals('P', position["e2"])
    }

    @Test fun rejectsMalformedRank() {
        assertThrows(IllegalArgumentException::class.java) {
            ChessPosition.fromFen("8/8/8/8/8/8/8/9 w - - 0 1")
        }
    }
}
