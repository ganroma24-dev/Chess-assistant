package com.example.chessassistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BoardRegionTest {
    @Test
    fun clampsRectangleToScreenBounds() {
        val region = BoardRegion(x = 0.92f, y = 0.91f, width = 0.70f, height = 0.80f).sanitized()
        assertTrue(region.x >= 0f && region.y >= 0f)
        assertTrue(region.right <= 1f)
        assertTrue(region.bottom <= 1f)
    }

    @Test
    fun preservesMinimumSelectableSize() {
        val region = BoardRegion(width = 0.01f, height = 0.02f).sanitized()
        assertEquals(BoardRegion.MIN_SIZE, region.width, 0.0001f)
        assertEquals(BoardRegion.MIN_SIZE, region.height, 0.0001f)
    }

    @Test
    fun movingRectangleDoesNotChangeItsSize() {
        val initial = BoardRegion()
        val moved = initial.withX(0.18f).withY(0.30f)
        assertEquals(initial.width, moved.width, 0.0001f)
        assertEquals(initial.height, moved.height, 0.0001f)
        assertEquals(0.18f, moved.x, 0.0001f)
        assertEquals(0.30f, moved.y, 0.0001f)
    }
}
