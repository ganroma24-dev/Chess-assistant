package com.example.chessassistant

import org.junit.Assert.*
import org.junit.Test

class ChessRulesTest {
    @Test fun initialPositionHasTwentyLegalMoves() {
        assertEquals(20, ChessRules.legalMoves(ChessPosition.fromFen(ChessPosition.START_FEN)).size)
    }

    @Test fun resolvesAndAppliesOpeningSan() {
        val start = ChessPosition.fromFen(ChessPosition.START_FEN)
        val after = ChessRules.apply(start, ChessRules.resolveSan(start, "e4"))
        assertEquals('P', after["e4"])
        assertEquals('b', after.activeColor)
        assertEquals("e3", after.enPassant)
    }

    @Test fun replaysPgnAndKeepsEveryPly() {
        val replay = PgnReplay.build("1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 1-0")
        assertEquals(6, replay.moves.size)
        assertEquals(7, replay.positions.size)
        assertEquals('b', replay.positions.last().activeColor)
    }

    @Test fun trackerRecognizesExactlyOneLegalMove() {
        val tracker = MoveTracker()
        val after = ChessRules.apply(tracker.position, ChessRules.resolveSan(tracker.position, "e4"))
        val update = tracker.acceptObservation(after.squares)
        assertEquals("e2e4", update.move?.uci())
        assertEquals(after.toFen(), tracker.position.toFen())
    }

    @Test fun supportsBothCastlingSides() {
        val open = ChessPosition.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1")
        val legal = ChessRules.legalMoves(open).map { it.uci() }
        assertTrue("e1g1" in legal)
        assertTrue("e1c1" in legal)
    }

    @Test fun supportsEnPassantCapture() {
        var p = ChessPosition.fromFen(ChessPosition.START_FEN)
        listOf("e4", "a6", "e5", "d5").forEach { p = ChessRules.apply(p, ChessRules.resolveSan(p, it)) }
        p = ChessRules.apply(p, ChessRules.resolveSan(p, "exd6"))
        assertEquals('P', p["d6"])
        assertEquals('.', p["d5"])
    }


    @Test fun supportsPromotion() {
        val position = ChessPosition.fromFen("4k3/P7/8/8/8/8/8/4K3 w - - 0 1")
        val promoted = ChessRules.apply(position, ChessRules.resolveSan(position, "a8=Q+"))
        assertEquals('Q', promoted["a8"])
    }

    @Test fun rejectsIllegalSan() {
        val start = ChessPosition.fromFen(ChessPosition.START_FEN)
        assertFalse(runCatching { ChessRules.resolveSan(start, "Qh5") }.isSuccess)
    }
}
