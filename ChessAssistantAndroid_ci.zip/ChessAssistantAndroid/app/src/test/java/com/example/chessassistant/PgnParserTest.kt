package com.example.chessassistant

import org.junit.Assert.*
import org.junit.Test

class PgnParserTest {
    @Test fun extractsMainLineAndResult() {
        val game = PgnParser.parse("""[Event "Training"]
            1. e4 {comment} e5 2. Nf3 (2. Bc4 Bc5) Nc6 1-0""")
        assertEquals("Training", game.headers["Event"])
        assertEquals(listOf("e4", "e5", "Nf3", "Nc6"), game.moves)
        assertEquals("1-0", game.result)
    }
}
