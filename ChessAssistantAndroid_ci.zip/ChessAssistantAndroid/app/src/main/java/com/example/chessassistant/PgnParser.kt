package com.example.chessassistant

/** Extracts headers and the main-line SAN sequence from a PGN document. */
object PgnParser {
    data class Game(val headers: Map<String, String>, val moves: List<String>, val result: String?)

    fun parse(pgn: String): Game {
        val headers = linkedMapOf<String, String>()
        val movetext = pgn.replace(Regex("(?m)^\\s*\\[([A-Za-z0-9_]+)\\s+\\\"(.*?)\\\"\\s*]\\s*$")) { match ->
            headers[match.groupValues[1]] = match.groupValues[2]
            " "
        }
        val mainLine = StringBuilder()
        var braceDepth = 0
        var variationDepth = 0
        var semicolonComment = false
        movetext.forEach { ch ->
            when {
                semicolonComment -> if (ch == '\n' || ch == '\r') { semicolonComment = false; mainLine.append(' ') }
                braceDepth > 0 -> if (ch == '{') braceDepth++ else if (ch == '}') braceDepth--
                variationDepth > 0 -> if (ch == '(') variationDepth++ else if (ch == ')') variationDepth--
                ch == ';' -> semicolonComment = true
                ch == '{' -> braceDepth = 1
                ch == '(' -> variationDepth = 1
                else -> mainLine.append(ch)
            }
        }
        val tokens = mainLine.toString().split(Regex("\\s+")).filter { it.isNotBlank() }
        val cleaned = tokens.mapNotNull { raw ->
            val token = raw.replace(Regex("^\\d+\\.(?:\\.\\.)?"), "").trim()
            token.takeIf { it.isNotEmpty() && !it.matches(Regex("\\$\\d+")) }
        }
        val result = cleaned.lastOrNull { it in RESULTS }
        val moves = cleaned.takeWhile { it !in RESULTS }
        return Game(headers, moves, result ?: headers["Result"]?.takeIf { it in RESULTS })
    }

    private val RESULTS = setOf("1-0", "0-1", "1/2-1/2", "*")
}
