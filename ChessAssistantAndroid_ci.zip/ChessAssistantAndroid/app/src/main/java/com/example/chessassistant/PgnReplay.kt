package com.example.chessassistant

/** Replays a PGN main line with legality checks and keeps every resulting position for navigation. */
object PgnReplay {
    data class Replay(val game: PgnParser.Game, val positions: List<ChessPosition>, val moves: List<ChessMove>)

    fun build(pgn: String): Replay {
        val game = PgnParser.parse(pgn)
        val initialFen = game.headers["FEN"] ?: ChessPosition.START_FEN
        var position = ChessPosition.fromFen(initialFen)
        val positions = mutableListOf(position)
        val moves = mutableListOf<ChessMove>()
        game.moves.forEachIndexed { index, san ->
            val move = try { ChessRules.resolveSan(position, san) }
            catch (error: Exception) { throw IllegalArgumentException("Ход ${index + 1} (${san}): ${error.message}", error) }
            position = ChessRules.apply(position, move)
            moves += move
            positions += position
        }
        return Replay(game, positions, moves)
    }
}
