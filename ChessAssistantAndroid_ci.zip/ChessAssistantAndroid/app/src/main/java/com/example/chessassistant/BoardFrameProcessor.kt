package com.example.chessassistant

import android.media.Image
import kotlin.math.abs
import kotlin.math.floor

/**
 * First-stage, privacy-preserving board frame preprocessor.
 * It samples only the selected rectangle and retains a 8x8 luminance descriptor;
 * it does not save screenshots or identify chess pieces yet.
 */
internal data class BoardFrameObservation(
    val changed: Boolean,
    val meanDifference: Float,
    val squareLuminance: FloatArray
)

internal class BoardFrameProcessor {
    private var previousDescriptor: FloatArray? = null

    fun process(image: Image, region: BoardRegion): BoardFrameObservation? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        if (pixelStride < 3 || image.width <= 0 || image.height <= 0) return null

        val safeRegion = region.sanitized()
        val left = floor(safeRegion.x * image.width).toInt().coerceIn(0, image.width - 1)
        val top = floor(safeRegion.y * image.height).toInt().coerceIn(0, image.height - 1)
        val cropWidth = floor(safeRegion.width * image.width).toInt().coerceAtLeast(1)
            .coerceAtMost(image.width - left)
        val cropHeight = floor(safeRegion.height * image.height).toInt().coerceAtLeast(1)
            .coerceAtMost(image.height - top)
        if (cropWidth < 8 || cropHeight < 8) return null

        // Sample a small 64x64 grid directly from Image's RGBA plane. No full screenshot bitmap is made.
        val sampledLuma = FloatArray(64 * 64)
        val limit = buffer.limit()
        for (sampleY in 0 until 64) {
            val sourceY = top + (((sampleY + 0.5f) * cropHeight) / 64f).toInt().coerceIn(0, cropHeight - 1)
            val rowOffset = sourceY * rowStride
            for (sampleX in 0 until 64) {
                val sourceX = left + (((sampleX + 0.5f) * cropWidth) / 64f).toInt().coerceIn(0, cropWidth - 1)
                val offset = rowOffset + sourceX * pixelStride
                if (offset < 0 || offset + 2 >= limit) return null
                val red = buffer.get(offset).toInt() and 0xFF
                val green = buffer.get(offset + 1).toInt() and 0xFF
                val blue = buffer.get(offset + 2).toInt() and 0xFF
                sampledLuma[sampleY * 64 + sampleX] = 0.299f * red + 0.587f * green + 0.114f * blue
            }
        }

        // One mean luminance value per chessboard square (8 x 8).
        val descriptor = FloatArray(64)
        for (squareY in 0 until 8) {
            for (squareX in 0 until 8) {
                var sum = 0f
                for (dy in 0 until 8) {
                    for (dx in 0 until 8) {
                        val sampleX = squareX * 8 + dx
                        val sampleY = squareY * 8 + dy
                        sum += sampledLuma[sampleY * 64 + sampleX]
                    }
                }
                descriptor[squareY * 8 + squareX] = sum / 64f
            }
        }

        val previous = previousDescriptor
        var difference = 0f
        if (previous != null) {
            for (index in descriptor.indices) difference += abs(descriptor[index] - previous[index])
            difference /= descriptor.size
        }
        previousDescriptor = descriptor.copyOf()
        return BoardFrameObservation(
            changed = previous != null && difference >= CHANGE_THRESHOLD,
            meanDifference = difference,
            squareLuminance = descriptor
        )
    }

    fun reset() {
        previousDescriptor = null
    }

    private companion object {
        const val CHANGE_THRESHOLD = 5.0f
    }
}
