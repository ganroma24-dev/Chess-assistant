package com.example.chessassistant

/**
 * A board rectangle expressed in normalized screen coordinates (0..1).
 * It deliberately contains no Android types so the geometry can be unit-tested separately.
 */
data class BoardRegion(
    val x: Float = 0.10f,
    val y: Float = 0.18f,
    val width: Float = 0.80f,
    val height: Float = 0.64f
) {
    val right: Float get() = x + width
    val bottom: Float get() = y + height

    fun sanitized(minSize: Float = MIN_SIZE): BoardRegion {
        val safeWidth = width.coerceIn(minSize, 1f)
        val safeHeight = height.coerceIn(minSize, 1f)
        val safeX = x.coerceIn(0f, 1f - safeWidth)
        val safeY = y.coerceIn(0f, 1f - safeHeight)
        return BoardRegion(safeX, safeY, safeWidth, safeHeight)
    }

    fun withX(value: Float) = copy(x = value).sanitized()
    fun withY(value: Float) = copy(y = value).sanitized()
    fun withWidth(value: Float) = copy(width = value).sanitized()
    fun withHeight(value: Float) = copy(height = value).sanitized()

    companion object {
        const val MIN_SIZE = 0.15f
    }
}
