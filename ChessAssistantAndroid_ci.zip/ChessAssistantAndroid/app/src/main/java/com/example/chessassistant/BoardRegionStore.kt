package com.example.chessassistant

import android.content.Context

/** Persists the user's manually calibrated screen rectangle. */
object BoardRegionStore {
    private const val PREFS = "board_region"
    private const val KEY_X = "x"
    private const val KEY_Y = "y"
    private const val KEY_WIDTH = "width"
    private const val KEY_HEIGHT = "height"

    fun load(context: Context): BoardRegion {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return BoardRegion(
            x = prefs.getFloat(KEY_X, 0.10f),
            y = prefs.getFloat(KEY_Y, 0.18f),
            width = prefs.getFloat(KEY_WIDTH, 0.80f),
            height = prefs.getFloat(KEY_HEIGHT, 0.64f)
        ).sanitized()
    }

    fun save(context: Context, region: BoardRegion) {
        val safe = region.sanitized()
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putFloat(KEY_X, safe.x)
            .putFloat(KEY_Y, safe.y)
            .putFloat(KEY_WIDTH, safe.width)
            .putFloat(KEY_HEIGHT, safe.height)
            .apply()
    }
}
