package com.example.chessassistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Board finder for screenshots: scores square candidates by the alternating light/dark square pattern. */
object BoardDetector {
    data class Detection(val rect: Rect, val confidence: Float)

    fun detect(bitmap: Bitmap, search: Rect = Rect(0, 0, bitmap.width, bitmap.height)): Detection? {
        val bounds = Rect(search).apply { intersect(0, 0, bitmap.width, bitmap.height) }
        if (bounds.width() < 80 || bounds.height() < 80) return null
        val scale = 160f / max(bounds.width(), bounds.height())
        val smallW = max(1, (bounds.width() * scale).toInt())
        val smallH = max(1, (bounds.height() * scale).toInt())
        val region = Bitmap.createBitmap(bitmap, bounds.left, bounds.top, bounds.width(), bounds.height())
        val small = Bitmap.createScaledBitmap(region, smallW, smallH, true)
        if (small !== region) region.recycle()
        var best: Detection? = null
        val maxSize = min(smallW, smallH) - 4
        for (size in 64..maxSize step 4) {
            for (top in 2..(smallH - size) step 4) for (left in 2..(smallW - size) step 4) {
                var light = 0.0; var dark = 0.0; var lightN = 0; var darkN = 0
                for (rank in 0 until 8) for (file in 0 until 8) {
                    val cx = left + ((file + .5f) * size / 8f).toInt()
                    val cy = top + ((rank + .5f) * size / 8f).toInt()
                    val color = small.getPixel(cx.coerceIn(0, smallW - 1), cy.coerceIn(0, smallH - 1))
                    val luma = .299 * ((color shr 16) and 255) + .587 * ((color shr 8) and 255) + .114 * (color and 255)
                    if ((rank + file) % 2 == 0) { light += luma; lightN++ } else { dark += luma; darkN++ }
                }
                val contrast = abs(light / lightN - dark / darkN).toFloat()
                val score = contrast / 255f + (size / maxSize.toFloat()) * .025f
                if (score > (best?.confidence ?: .055f)) {
                    best = Detection(Rect(
                        bounds.left + (left / scale).toInt(), bounds.top + (top / scale).toInt(),
                        bounds.left + ((left + size) / scale).toInt(), bounds.top + ((top + size) / scale).toInt()
                    ), score)
                }
            }
        }
        small.recycle()
        return best?.takeIf { it.confidence >= .075f }
    }
}

/** Optional on-device TFLite classifier. Model contract: [batch,64,64,3] RGB float 0..1, 13 scores. */
class TflitePieceRecognizer(context: Context, modelFileName: String = "piece_classifier.tflite") : AutoCloseable {
    companion object { const val LABELS = ".PNBRQKpnbrqk" }
    private val interpreter: Interpreter? = runCatching {
        val file = java.io.File(context.filesDir, modelFileName)
        val modelBuffer = if (file.isFile()) {
            FileInputStream(file).channel.use { channel -> channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size()) }
        } else {
            val bytes = context.assets.open(modelFileName).use { it.readBytes() }
            ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder()).apply { put(bytes); rewind() }
        }
        Interpreter(modelBuffer)
    }.getOrNull()

    val isReady: Boolean get() = interpreter != null

    fun recognize(board: Bitmap): CharArray? {
        val engine = interpreter ?: return null
        val normalized = Bitmap.createScaledBitmap(board, 512, 512, true)
        val pixels = IntArray(512 * 512)
        normalized.getPixels(pixels, 0, 512, 0, 0, 512, 512)
        normalized.recycle()
        val input = ByteBuffer.allocateDirect(64 * 64 * 64 * 3 * 4).order(ByteOrder.nativeOrder())
        for (square in 0 until 64) {
            val rank = square / 8; val file = square % 8
            for (y in 0 until 64) for (x in 0 until 64) {
                val color = pixels[(rank * 64 + y) * 512 + file * 64 + x]
                input.putFloat(((color shr 16) and 255) / 255f)
                input.putFloat(((color shr 8) and 255) / 255f)
                input.putFloat((color and 255) / 255f)
            }
        }
        input.rewind()
        engine.resizeInput(0, intArrayOf(64, 64, 64, 3))
        engine.allocateTensors()
        val output = Array(64) { FloatArray(LABELS.length) }
        engine.run(input, output)
        for (square in 0 until 64) {
            val label = output[square].indices.maxByOrNull { output[square][it] } ?: 0
            if (output[square][label] < 0.45f) return null
            result[square] = LABELS[label]
        }
        return result.copyOf()
    }

    private val result = CharArray(64)
    override fun close() { interpreter?.close() }
}

/** Finds a board in a user-approved screen frame and returns the rectified axis-aligned square crop. */
class BoardRecognitionPipeline(context: Context) : AutoCloseable {
    private val recognizer = TflitePieceRecognizer(context)
    private val initialSide = runCatching {
        val fen = context.getSharedPreferences("chess_position", Context.MODE_PRIVATE).getString("fen", ChessPosition.START_FEN)
        ChessPosition.fromFen(fen ?: ChessPosition.START_FEN).activeColor
    }.getOrDefault('w')
    val modelReady: Boolean get() = recognizer.isReady

    data class Result(val detection: BoardDetector.Detection?, val position: ChessPosition?, val move: ChessMove?, val note: String)
    private var tracker: MoveTracker? = null
    private var pendingSquares: List<Char>? = null
    private var pendingCount = 0

    fun process(frame: Bitmap, fallback: Rect): Result {
        val detected = BoardDetector.detect(frame, fallback)
        val rect = detected?.rect ?: fallback
        if (rect.width() < 8 || rect.height() < 8) return Result(detected, null, null, "Не удалось определить область доски")
        val side = min(rect.width(), rect.height())
        val cropLeft = rect.left + (rect.width() - side) / 2
        val cropTop = rect.top + (rect.height() - side) / 2
        val crop = Bitmap.createBitmap(frame, cropLeft, cropTop, side, side)
        val pieces = try {
            if (!recognizer.isReady) return Result(detected, null, null, "Доска найдена; модель фигур отсутствует (piece_classifier.tflite)")
            recognizer.recognize(crop)
        } finally { crop.recycle() }
        if (pieces == null) return Result(detected, null, null, "Распознавание недоступно")
        val squares = pieces.toList()
        if (pendingSquares == squares) pendingCount++ else { pendingSquares = squares; pendingCount = 1 }
        if (pendingCount < 2) return Result(detected, tracker?.position, null, "Ожидание стабильного кадра для подтверждения позиции")
        if (tracker == null) {
            tracker = MoveTracker(ChessPosition(squares, activeColor = initialSide, castling = "-"))
            return Result(detected, tracker?.position, null, "Начальная позиция распознана")
        }
        val update = tracker!!.acceptObservation(squares)
        return Result(detected, update.position, update.move, update.status)
    }

    override fun close() = recognizer.close()
}
