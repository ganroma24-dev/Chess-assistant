package com.example.chessassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Bitmap
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

/**
 * Consent-based capture service. It samples only the calibrated board region,
 * keeps a compact luminance descriptor in memory, and never writes screenshots to disk.
 */
class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var processingThread: HandlerThread? = null
    private var processingHandler: Handler? = null
    private var frameProcessor: BoardFrameProcessor? = null
    private var recognitionPipeline: BoardRecognitionPipeline? = null
    private var boardRegion: BoardRegion = BoardRegion()
    private var lastProcessedAt = 0L
    private var stopping = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY

        createChannel()
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Chess Assistant")
            .setContentText("Демонстрация экрана активна · анализ выбранной области")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (data == null) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        return try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            boardRegion = BoardRegionStore.load(this)
            frameProcessor = BoardFrameProcessor()
            recognitionPipeline = BoardRecognitionPipeline(this)
            startProcessingThread()
            registerProjectionCallback()
            startVirtualDisplay()
            START_NOT_STICKY
        } catch (error: Exception) {
            Log.e(TAG, "Unable to start screen capture", error)
            stopCapture()
            stopSelf()
            START_NOT_STICKY
        }
    }

    private fun startProcessingThread() {
        processingThread = HandlerThread("ChessBoardFrameProcessor").also { it.start() }
        processingHandler = Handler(processingThread!!.looper)
    }

    private fun registerProjectionCallback() {
        val callback = object : MediaProjection.Callback() {
            override fun onStop() {
                // Android or the user stopped projection from system UI.
                stopCapture(stopProjection = false)
                stopSelf()
            }
        }
        projectionCallback = callback
        projection?.registerCallback(callback, processingHandler!!)
    }

    private fun startVirtualDisplay() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ imageReader ->
            val image = imageReader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = SystemClock.elapsedRealtime()
                if (now - lastProcessedAt >= FRAME_INTERVAL_MS) {
                    lastProcessedAt = now
                    processBoardFrame(image)
                }
            } catch (error: Exception) {
                Log.w(TAG, "Could not process captured frame", error)
            } finally {
                image.close()
            }
        }, processingHandler)

        virtualDisplay = projection?.createVirtualDisplay(
            "ChessAssistantCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, processingHandler!!
        )
    }

    private fun processBoardFrame(image: Image) {
        val observation = frameProcessor?.process(image, boardRegion)
        if (observation?.changed == true) Log.d(TAG, "Board image changed; mean luminance delta=${observation.meanDifference}")
        val plane = image.planes.firstOrNull() ?: return
        if (plane.pixelStride < 4) return
        val pixels = IntArray(image.width * image.height)
        val buffer = plane.buffer.duplicate()
        for (y in 0 until image.height) for (x in 0 until image.width) {
            val offset = y * plane.rowStride + x * plane.pixelStride
            if (offset + 3 >= buffer.limit()) continue
            val r = buffer.get(offset).toInt() and 0xff
            val g = buffer.get(offset + 1).toInt() and 0xff
            val b = buffer.get(offset + 2).toInt() and 0xff
            val a = buffer.get(offset + 3).toInt() and 0xff
            pixels[y * image.width + x] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
        val bitmap = Bitmap.createBitmap(pixels, image.width, image.height, Bitmap.Config.ARGB_8888)
        try {
            val left = (boardRegion.x * image.width).toInt().coerceIn(0, image.width - 1)
            val top = (boardRegion.y * image.height).toInt().coerceIn(0, image.height - 1)
            val right = ((boardRegion.x + boardRegion.width) * image.width).toInt().coerceIn(left + 1, image.width)
            val bottom = ((boardRegion.y + boardRegion.height) * image.height).toInt().coerceIn(top + 1, image.height)
            val result = recognitionPipeline?.process(bitmap, Rect(left, top, right, bottom))
            if (result != null) Log.d(TAG, "${result.note}; move=${result.move?.uci()}; board=${result.detection?.rect}; confidence=${result.detection?.confidence}")
        } finally { bitmap.recycle() }
    }

    private fun stopCapture(stopProjection: Boolean = true) {
        if (stopping) return
        stopping = true

        reader?.setOnImageAvailableListener(null, null)
        virtualDisplay?.release()
        virtualDisplay = null
        reader?.close()
        reader = null

        val activeProjection = projection
        projection = null
        projectionCallback?.let { callback ->
            try {
                activeProjection?.unregisterCallback(callback)
            } catch (_: Exception) {
                // Projection may already have been stopped by Android.
            }
        }
        projectionCallback = null
        if (stopProjection) {
            try {
                activeProjection?.stop()
            } catch (_: Exception) {
                // Safe to ignore when Android already ended the session.
            }
        }

        processingThread?.quitSafely()
        processingThread = null
        processingHandler = null
        frameProcessor?.reset()
        frameProcessor = null
        recognitionPipeline?.close()
        recognitionPipeline = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopping = false
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Screen capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val ACTION_STOP = "com.example.chessassistant.STOP_CAPTURE"
        private const val TAG = "ChessAssistantCapture"
        private const val CHANNEL_ID = "chess_capture"
        private const val NOTIFICATION_ID = 4101
        private const val FRAME_INTERVAL_MS = 1_000L
    }
}
