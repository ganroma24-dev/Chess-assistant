package com.example.chessassistant

import java.io.File
import java.util.concurrent.TimeUnit
import java.util.concurrent.LinkedBlockingQueue

/** Bounded UCI session. Run from Dispatchers.IO; the engine process is destroyed on timeout. */
class StockfishUci(private val executable: File) {
    data class Analysis(val bestMove: String, val infoLines: List<String>) {
        val latestInfo: String? get() = infoLines.lastOrNull()
        val score: String? get() = infoLines.lastOrNull { it.contains(" score ") }?.let { line ->
            Regex(" score (cp|mate) (-?\\d+)").find(line)?.let { m ->
                if (m.groupValues[1] == "mate") "Мат за ${m.groupValues[2]}" else "Оценка ${m.groupValues[2].toInt() / 100.0}"
            }
        }
    }

    fun isInstalled(): Boolean = executable.isFile && executable.canExecute()

    fun analyze(fen: String, depth: Int = 12, timeoutMillis: Long = 30_000): Analysis {
        require(depth in 1..30)
        require(timeoutMillis in 1_000..120_000)
        require(isInstalled()) { "Stockfish не установлен: ${executable.absolutePath}" }
        ChessPosition.fromFen(fen)
        val process = ProcessBuilder(executable.absolutePath).redirectErrorStream(true).start()
        val writer = process.outputStream.bufferedWriter()
        val reader = process.inputStream.bufferedReader()
        val lines = LinkedBlockingQueue<String>()
        val readerThread = Thread {
            try {
                while (true) {
                    val line = reader.readLine() ?: break
                    lines.put(line)
                }
                lines.offer("__EOF__")
            } catch (_: Exception) { lines.offer("__EOF__") }
        }.apply { name = "StockfishOutput"; isDaemon = true; start() }
        val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMillis)
        val info = mutableListOf<String>()
        fun readLineBounded(): String {
            val remaining = deadline - System.nanoTime()
            if (remaining <= 0) throw java.util.concurrent.TimeoutException("Stockfish: превышено время анализа")
            val line = lines.poll(remaining, TimeUnit.NANOSECONDS)
                ?: throw java.util.concurrent.TimeoutException("Stockfish: превышено время анализа")
            if (line == "__EOF__") error("Stockfish завершился без ответа")
            return line
        }
        try {
            writer.write("uci\n"); writer.flush()
            while (readLineBounded() != "uciok") Unit
            writer.write("isready\n"); writer.flush()
            while (readLineBounded() != "readyok") Unit
            writer.write("position fen $fen\ngo depth $depth\n"); writer.flush()
            while (true) {
                val line = readLineBounded()
                if (line.startsWith("info ")) info += line
                if (line.startsWith("bestmove ")) return Analysis(line.split(Regex("\\s+")).getOrElse(1) { "(none)" }, info)
            }
        } finally {
            runCatching { writer.write("quit\n"); writer.flush() }
            runCatching { writer.close() }
            runCatching { reader.close() }
            readerThread.interrupt()
            try {
                if (!process.waitFor(250, TimeUnit.MILLISECONDS)) process.destroyForcibly()
            } catch (interrupted: InterruptedException) {
                process.destroyForcibly()
                Thread.currentThread().interrupt()
            }
        }
    }
}
