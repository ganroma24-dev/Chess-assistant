package com.example.chessassistant

/** Synchronizes two recognized boards by matching their exact piece layout against legal moves. */
class MoveTracker(initial: ChessPosition = ChessPosition.fromFen(ChessPosition.START_FEN)) {
    var position: ChessPosition = initial
        private set

    data class Update(val move: ChessMove?, val position: ChessPosition, val status: String)

    fun reset(next: ChessPosition) { position = next }

    fun acceptObservation(observedSquares: List<Char>): Update {
        require(observedSquares.size == 64 && observedSquares.all { it == '.' || it in ChessPosition.PIECES })
        if (observedSquares == position.squares) return Update(null, position, "Позиция не изменилась")
        val matches = ChessRules.legalMoves(position).filter { move ->
            ChessRules.apply(position, move).squares == observedSquares
        }
        if (matches.size != 1) return Update(null, position, if (matches.isEmpty()) "Изменение не соответствует одному легальному ходу" else "Неоднозначное изменение доски")
        val move = matches.single()
        position = ChessRules.apply(position, move)
        return Update(move, position, "Ход ${move.uci()} распознан")
    }
}
