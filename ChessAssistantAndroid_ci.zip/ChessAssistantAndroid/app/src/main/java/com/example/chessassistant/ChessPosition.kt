package com.example.chessassistant

/** Immutable chessboard snapshot. Squares are stored rank 8 to rank 1, file a to h. */
data class ChessPosition(
    val squares: List<Char>,
    val activeColor: Char = 'w',
    val castling: String = "KQkq",
    val enPassant: String = "-",
    val halfmoveClock: Int = 0,
    val fullmoveNumber: Int = 1
) {
    init {
        require(squares.size == 64) { "A chessboard must contain 64 squares" }
        require(activeColor == 'w' || activeColor == 'b')
        require(castling == "-" || (castling.all { it in "KQkq" } && castling.toSet().size == castling.length))
        require(enPassant == "-" || enPassant.matches(Regex("[a-h][36]")))
        require(halfmoveClock >= 0 && fullmoveNumber >= 1)
        require(squares.all { it == '.' || it in PIECES })
    }

    operator fun get(square: String): Char {
        require(square.matches(Regex("[a-h][1-8]")))
        val file = square[0] - 'a'
        val rank = square[1] - '1'
        return squares[(7 - rank) * 8 + file]
    }

    fun withPiece(square: String, piece: Char): ChessPosition {
        require(square.matches(Regex("[a-h][1-8]")))
        require(piece == '.' || piece in PIECES)
        val index = (8 - (square[1] - '0')) * 8 + (square[0] - 'a')
        return copy(squares = squares.toMutableList().also { it[index] = piece })
    }

    fun toFen(): String {
        val placement = (0 until 8).joinToString("/") { rank ->
            val row = squares.subList(rank * 8, rank * 8 + 8)
            buildString {
                var empty = 0
                row.forEach { piece ->
                    if (piece == '.') empty++ else {
                        if (empty > 0) append(empty)
                        empty = 0
                        append(piece)
                    }
                }
                if (empty > 0) append(empty)
            }
        }
        return "$placement $activeColor $castling $enPassant $halfmoveClock $fullmoveNumber"
    }

    companion object {
        const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
        val PIECES = "pnbrqkPNBRQK".toSet()
        val EMPTY = ChessPosition(List(64) { '.' })

        fun fromFen(fen: String): ChessPosition {
            val fields = fen.trim().split(Regex("\\s+"))
            require(fields.size == 6) { "FEN должен содержать 6 полей" }
            val ranks = fields[0].split('/')
            require(ranks.size == 8) { "В FEN должно быть 8 горизонталей" }
            val board = mutableListOf<Char>()
            ranks.forEach { row ->
                var count = 0
                row.forEach { token ->
                    if (token in '1'..'8') {
                        val empty = token - '0'
                        count += empty
                        repeat(empty) { board += '.' }
                    } else {
                        require(token in PIECES) { "Недопустимая фигура: $token" }
                        count++
                        board += token
                    }
                }
                require(count == 8) { "В каждой горизонтали должно быть 8 клеток" }
            }
            require(fields[1] == "w" || fields[1] == "b") { "Цвет хода должен быть w или b" }
            require(fields[2] == "-" || (fields[2].all { it in "KQkq" } && fields[2].toSet().size == fields[2].length))
            require(fields[3] == "-" || fields[3].matches(Regex("[a-h][36]")))
            val half = fields[4].toIntOrNull()?.also { require(it >= 0) } ?: error("Некорректный счётчик полуходов")
            val full = fields[5].toIntOrNull()?.also { require(it >= 1) } ?: error("Некорректный номер хода")
            return ChessPosition(board, fields[1][0], fields[2], fields[3], half, full)
        }
    }
}
