package com.example.chessassistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ChessAssistantScreen(this) }
    }
}

@Composable
private fun ChessAssistantScreen(activity: Activity) {
    val context = activity
    var captureActive by remember { mutableStateOf(false) }
    var overlayEnabled by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var message by remember { mutableStateOf("Готов к настройке захвата экрана") }
    var region by remember { mutableStateOf(BoardRegionStore.load(context)) }

    fun updateRegion(next: BoardRegion) {
        region = next.sanitized()
        BoardRegionStore.save(context, region)
    }

    val captureLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(context, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(context, service)
            captureActive = true
            message = "Захват запущен. Используй системный индикатор, чтобы остановить его."
        } else {
            message = "Разрешение на захват не выдано"
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF080F1D),
            surface = Color(0xFF17243A),
            primary = Color(0xFF83BFFF),
            onBackground = Color(0xFFF3F7FF),
            onSurface = Color(0xFFF3F7FF)
        )
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF172D4D), Color(0xFF0B1424), Color(0xFF070C16)))
            )
        ) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                GlassCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("♟", fontSize = 34.sp, color = Color(0xFF91C9FF))
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Chess Assistant", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            Text("Study positions · PGN review", color = Color(0xFFB4C7E3), fontSize = 12.sp)
                        }
                        Text("● DEMO", color = Color(0xFF7CE5B0), fontSize = 11.sp)
                    }
                }

                GlassCard {
                    Text("Область шахматной доски", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Укажи прямоугольник, в котором находится доска. Координаты сохраняются на устройстве и применяются к кадрам после разрешения Android.",
                        color = Color(0xFFB4C7E3), fontSize = 13.sp
                    )
                    Spacer(Modifier.height(14.dp))
                    BoardPreview()
                    Spacer(Modifier.height(12.dp))
                    RegionSlider("Слева", region.x, 0f..(1f - region.width)) { updateRegion(region.withX(it)) }
                    RegionSlider("Сверху", region.y, 0f..(1f - region.height)) { updateRegion(region.withY(it)) }
                    RegionSlider("Ширина", region.width, BoardRegion.MIN_SIZE..(1f - region.x)) { updateRegion(region.withWidth(it)) }
                    RegionSlider("Высота", region.height, BoardRegion.MIN_SIZE..(1f - region.y)) { updateRegion(region.withHeight(it)) }
                    Text(
                        "X ${region.x.asPercent()} · Y ${region.y.asPercent()} · W ${region.width.asPercent()} · H ${region.height.asPercent()}",
                        color = Color(0xFF9FB4D2), fontSize = 11.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Настрой прямоугольник экрана. Детектор дополнительно ищет шахматную сетку внутри него; для нестандартных тем оставь ручную калибровку как резерв.",
                        color = Color(0xFF7F93B2), fontSize = 11.sp, lineHeight = 16.sp
                    )
                }

                BoardEditorCard(context)
                PgnImportCard(context)

                GlassCard {
                    Text("Захват экрана", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Android покажет системный запрос. Захват начинается только после твоего разрешения.",
                        color = Color(0xFFB4C7E3), fontSize = 13.sp
                    )
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = {
                            val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                            captureLauncher.launch(manager.createScreenCaptureIntent())
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !captureActive
                    ) { Text(if (captureActive) "Захват активен" else "Начать демонстрацию экрана") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            context.startService(Intent(context, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP))
                            captureActive = false
                            message = "Захват остановлен"
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = captureActive
                    ) { Text("Остановить захват") }
                }

                GlassCard {
                    Text("Плавающее окно", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Разрешение Android «Поверх других приложений» нужно для видимой плавающей панели.",
                        color = Color(0xFFB4C7E3), fontSize = 13.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        if (!Settings.canDrawOverlays(context)) {
                            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                            context.startActivity(intent)
                        } else {
                            overlayEnabled = true
                            context.startService(Intent(context, OverlayService::class.java))
                            message = "Плавающая панель запущена"
                        }
                    }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (overlayEnabled) "Показать плавающую панель" else "Разрешить и показать панель")
                    }
                    Text(
                        if (overlayEnabled) "Разрешение: предоставлено" else "Разрешение: пока не предоставлено",
                        color = Color(0xFF9FB4D2), fontSize = 11.sp
                    )
                }

                GlassCard {
                    Text("Состояние", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(5.dp))
                    Text(message, color = Color(0xFFB4C7E3), fontSize = 13.sp)
                    AnimatedVisibility(visible = captureActive, enter = fadeIn(), exit = fadeOut()) {
                        Text("● Захват включён", color = Color(0xFF7CE5B0), modifier = Modifier.padding(top = 8.dp))
                    }
                }
                Text(
                    "Доступны детекция сетки, опциональное распознавание через TFLite-модель, проверка ходов, PGN replay и ручной анализ Stockfish учебных позиций. Для рейтинговых онлайн-партий скрытые подсказки не предоставляются.",
                    color = Color(0xFF7F93B2), fontSize = 11.sp, lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
private fun RegionSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onValueChange: (Float) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color(0xFFE8F1FF), fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(value.asPercent(), color = Color(0xFF9FB4D2), fontSize = 12.sp)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onValueChange, valueRange = range, steps = 98)
    }
}

@Composable
private fun BoardPreview() {
    Box(
        Modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            Modifier.size(164.dp)
                .border(1.dp, Color(0x668BC5FF), RoundedCornerShape(12.dp))
        ) {
            val cell = size.width / 8f
            for (row in 0 until 8) {
                for (column in 0 until 8) {
                    val light = (row + column) % 2 == 0
                    drawRect(
                        color = if (light) Color(0xFFD7E5F7) else Color(0xFF54779F),
                        topLeft = androidx.compose.ui.geometry.Offset(column * cell, row * cell),
                        size = androidx.compose.ui.geometry.Size(cell, cell)
                    )
                }
            }
        }
    }
}

@Composable
private fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .background(Color(0xB51C2D49), RoundedCornerShape(26.dp))
            .border(1.dp, Color(0x397FB9FF), RoundedCornerShape(26.dp))
            .padding(18.dp),
        content = content
    )
}

private fun Float.asPercent(): String = "${(this * 100f).roundToInt()}%"


@Composable
private fun BoardEditorCard(context: Context) {
    val prefs = remember { context.getSharedPreferences("chess_position", Context.MODE_PRIVATE) }
    var position by remember {
        mutableStateOf(runCatching {
            ChessPosition.fromFen(prefs.getString("fen", ChessPosition.START_FEN) ?: ChessPosition.START_FEN)
        }.getOrDefault(ChessPosition.fromFen(ChessPosition.START_FEN)))
    }
    var selectedPiece by remember { mutableStateOf('P') }
    var fenText by remember { mutableStateOf(position.toFen()) }
    var status by remember { mutableStateOf("Позицию можно расставить вручную или загрузить через FEN.") }
    val stockfish = remember { StockfishUci(java.io.File(context.filesDir, "engine/stockfish")) }
    val scope = rememberCoroutineScope()
    var analyzing by remember { mutableStateOf(false) }
    var analysisText by remember { mutableStateOf("") }
    var analysisDepth by remember { mutableIntStateOf(14) }

    fun commit(next: ChessPosition) {
        position = next
        fenText = next.toFen()
        prefs.edit().putString("fen", fenText).apply()
    }

    GlassCard {
        Text("Редактор позиции", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Text("Учебная доска · ручная расстановка фигур", color = Color(0xFFB4C7E3), fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().aspectRatio(1f).border(1.dp, Color(0x668BC5FF), RoundedCornerShape(10.dp))) {
            for (rank in 0 until 8) {
                Row(Modifier.weight(1f)) {
                    for (file in 0 until 8) {
                        val squareIndex = rank * 8 + file
                        val piece = position.squares[squareIndex]
                        val squareName = "${'a' + file}${8 - rank}"
                        Box(
                            Modifier.weight(1f).fillMaxHeight()
                                .background(if ((rank + file) % 2 == 0) Color(0xFFD7E5F7) else Color(0xFF54779F))
                                .clickable { commit(position.withPiece(squareName, selectedPiece)) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                piece.glyph(),
                                fontSize = 27.sp,
                                color = if (piece.isUpperCase()) Color(0xFF101A2A) else Color(0xFFF8FAFF),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Выбранная фигура — нажми на клетку:", color = Color(0xFFB4C7E3), fontSize = 12.sp)
        val palette = listOf('P', 'N', 'B', 'R', 'Q', 'K', 'p', 'n', 'b', 'r', 'q', 'k', '.')
        palette.chunked(7).forEach { rowPieces ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                rowPieces.forEach { piece ->
                    val active = selectedPiece == piece
                    Surface(
                        modifier = Modifier.weight(1f).height(38.dp).clickable { selectedPiece = piece },
                        color = if (active) Color(0xFF416A9D) else Color(0xFF263B59),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (active) Color(0xFF9CCBFF) else Color(0x337FB9FF))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(if (piece == '.') "·" else piece.glyph(), fontSize = 20.sp)
                        }
                    }
                }
                if (rowPieces.size < 7) repeat(7 - rowPieces.size) { Spacer(Modifier.weight(1f)) }
            }
            Spacer(Modifier.height(5.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { commit(ChessPosition.fromFen(ChessPosition.START_FEN)); status = "Начальная позиция восстановлена" }, modifier = Modifier.weight(1f)) { Text("Начальная") }
            OutlinedButton(onClick = {
                val next = position.copy(activeColor = if (position.activeColor == 'w') 'b' else 'w')
                commit(next)
                status = "Ход: ${if (next.activeColor == 'w') "белых" else "чёрных"}"
            }, modifier = Modifier.weight(1f)) { Text(if (position.activeColor == 'w') "Ход белых" else "Ход чёрных") }
        }
        OutlinedTextField(
            value = fenText,
            onValueChange = { fenText = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("FEN") },
            minLines = 2,
            textStyle = MaterialTheme.typography.bodySmall
        )
        Button(onClick = {
            runCatching { ChessPosition.fromFen(fenText) }
                .onSuccess { commit(it); status = "FEN загружен и сохранён" }
                .onFailure { status = it.message ?: "Не удалось прочитать FEN" }
        }, modifier = Modifier.fillMaxWidth()) { Text("Загрузить FEN") }
        Text(status, color = Color(0xFFB4C7E3), fontSize = 12.sp)
        Spacer(Modifier.height(5.dp))
        Text("Глубина Stockfish: $analysisDepth", color = Color(0xFFB4C7E3), fontSize = 12.sp)
        Slider(value = analysisDepth.toFloat(), onValueChange = { analysisDepth = it.toInt() }, valueRange = 8f..20f, steps = 11)
        Button(
            onClick = {
                val fenSnapshot = position.toFen()
                analyzing = true
                analysisText = "Stockfish анализирует учебную позицию…"
                scope.launch {
                    val result = withContext(Dispatchers.IO) { runCatching { stockfish.analyze(fenSnapshot, depth = analysisDepth) } }
                    analyzing = false
                    analysisText = result.fold(
                        { "Лучший ход: ${it.bestMove} · ${it.score ?: "оценка не получена"}" },
                        { "Ошибка анализа: ${it.message ?: "неизвестная ошибка"}" }
                    )
                }
            },
            enabled = stockfish.isInstalled() && !analyzing,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (analyzing) "Анализ…" else "Анализировать учебную позицию") }
        if (analysisText.isNotBlank()) Text(analysisText, color = Color(0xFF9FC8FF), fontSize = 12.sp)
        Text(
            if (stockfish.isInstalled()) "Stockfish найден. Анализ запускается вручную для позиции в редакторе."
            else "Stockfish не установлен. Помести совместимый Android-бинарник в files/engine/stockfish; он не входит в архив.",
            color = Color(0xFF9FB4D2), fontSize = 11.sp, lineHeight = 15.sp
        )
        Text("Автораспознавание использует файл piece_classifier.tflite в приватной папке приложения. Без обученной модели доступна только детекция шахматной сетки.", color = Color(0xFF7F93B2), fontSize = 11.sp)
    }
}

private fun Char.glyph(): String = when (this) {
    'K' -> "♔"; 'Q' -> "♕"; 'R' -> "♖"; 'B' -> "♗"; 'N' -> "♘"; 'P' -> "♙"
    'k' -> "♚"; 'q' -> "♛"; 'r' -> "♜"; 'b' -> "♝"; 'n' -> "♞"; 'p' -> "♟"
    else -> ""
}


@Composable
private fun PgnImportCard(context: Context) {
    var pgn by remember { mutableStateOf("") }
    var replay by remember { mutableStateOf<PgnReplay.Replay?>(null) }
    var ply by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf("") }
    val stockfish = remember { StockfishUci(java.io.File(context.filesDir, "engine/stockfish")) }
    val scope = rememberCoroutineScope()
    var analyzing by remember { mutableStateOf(false) }
    var analysisText by remember { mutableStateOf("") }
    var analysisDepth by remember { mutableIntStateOf(14) }
    GlassCard {
        Text("Разбор завершённой партии", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Text("Вставь PGN завершённой партии. Ходы проверяются на легальность, а позицию можно листать по полуходам.", color = Color(0xFFB4C7E3), fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = pgn, onValueChange = { pgn = it }, modifier = Modifier.fillMaxWidth(), label = { Text("PGN") }, minLines = 4, maxLines = 8)
        Button(onClick = {
            runCatching { PgnReplay.build(pgn) }
                .onSuccess { replay = it; ply = 0; error = "" }
                .onFailure { replay = null; error = it.message ?: "Не удалось воспроизвести PGN" }
        }, enabled = pgn.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Проверить и открыть партию") }
        if (error.isNotBlank()) Text(error, color = Color(0xFFFFB4AB), fontSize = 12.sp)
        replay?.let { game ->
            val current = game.positions[ply]
            Text("${game.game.headers["White"] ?: "Белые"} — ${game.game.headers["Black"] ?: "Чёрные"} · ${game.game.result ?: "результат не указан"}", color = Color(0xFF9FC8FF), fontSize = 12.sp)
            Text("Полуход ${ply} из ${game.moves.size} · ${if (ply == 0) "Начальная позиция" else game.moves[ply - 1].uci()}", color = Color(0xFFE6EEFC), fontSize = 12.sp)
            ReplayBoard(current)
            Slider(value = ply.toFloat(), onValueChange = { ply = it.toInt().coerceIn(0, game.moves.size) }, valueRange = 0f..game.moves.size.coerceAtLeast(1).toFloat(), enabled = game.moves.isNotEmpty())
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { ply = 0 }, enabled = ply > 0, modifier = Modifier.weight(1f)) { Text("В начало") }
                OutlinedButton(onClick = { ply = (ply - 1).coerceAtLeast(0) }, enabled = ply > 0, modifier = Modifier.weight(1f)) { Text("Назад") }
                Button(onClick = { ply = (ply + 1).coerceAtMost(game.moves.size) }, enabled = ply < game.moves.size, modifier = Modifier.weight(1f)) { Text("Вперёд") }
            }
            Text("FEN: ${current.toFen()}", color = Color(0xFF9FB4D2), fontSize = 10.sp, lineHeight = 14.sp)
            Text("Глубина анализа: $analysisDepth", color = Color(0xFFB4C7E3), fontSize = 12.sp)
            Slider(value = analysisDepth.toFloat(), onValueChange = { analysisDepth = it.toInt() }, valueRange = 8f..20f, steps = 11)
            Button(onClick = {
                val fenSnapshot = current.toFen()
                analyzing = true
                analysisText = "Анализ позиции партии…"
                scope.launch {
                    val result = withContext(Dispatchers.IO) { runCatching { stockfish.analyze(fenSnapshot, depth = analysisDepth) } }
                    analyzing = false
                    analysisText = result.fold(
                        { "Лучший ход: ${it.bestMove} · ${it.score ?: "оценка не получена"}" },
                        { "Ошибка анализа: ${it.message ?: "неизвестная ошибка"}" }
                    )
                }
            }, enabled = stockfish.isInstalled() && !analyzing, modifier = Modifier.fillMaxWidth()) {
                Text(if (analyzing) "Анализ…" else "Анализировать эту позицию")
            }
            if (analysisText.isNotBlank()) Text(analysisText, color = Color(0xFF9FC8FF), fontSize = 12.sp)
            Text("Проверено ходов: ${game.moves.size}. Ошибки легальности приводят к остановке импорта с номером хода.", color = Color(0xFF7F93B2), fontSize = 11.sp)
        }
    }
}

@Composable
private fun ReplayBoard(position: ChessPosition) {
    Column(Modifier.fillMaxWidth().aspectRatio(1f).border(1.dp, Color(0x668BC5FF), RoundedCornerShape(10.dp))) {
        for (rank in 0 until 8) Row(Modifier.weight(1f)) {
            for (file in 0 until 8) {
                val piece = position.squares[rank * 8 + file]
                Box(Modifier.weight(1f).fillMaxHeight().background(if ((rank + file) % 2 == 0) Color(0xFFD7E5F7) else Color(0xFF54779F)), contentAlignment = Alignment.Center) {
                    Text(piece.glyph(), fontSize = 27.sp, color = if (piece.isUpperCase()) Color(0xFF101A2A) else Color(0xFFF8FAFF), textAlign = TextAlign.Center)
                }
            }
        }
    }
}
