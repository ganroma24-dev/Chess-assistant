package com.example.chessassistant

/** Coordinate move; files/ranks are zero-based with rank 0 = rank 1. */
data class ChessMove(val from: Int, val to: Int, val promotion: Char? = null) {
    fun uci(): String = "${squareName(from)}${squareName(to)}${promotion?.lowercaseChar() ?: ""}"
}

/** Small rules core used for move reconstruction and PGN replay. */
object ChessRules {
    private fun file(i: Int) = i % 8
    private fun rank(i: Int) = 7 - i / 8
    private fun inside(f: Int, r: Int) = f in 0..7 && r in 0..7
    private fun index(f: Int, r: Int) = (7 - r) * 8 + f
    private fun white(p: Char) = p.isUpperCase()
    private fun enemy(a: Char, b: Char) = b != '.' && b.lowercaseChar() != 'k' && white(a) != white(b)

    fun legalMoves(position: ChessPosition): List<ChessMove> {
        val side = position.activeColor == 'w'
        val pseudo = mutableListOf<ChessMove>()
        position.squares.forEachIndexed { i, p ->
            if (p == '.' || white(p) != side) return@forEachIndexed
            val f = file(i); val r = rank(i)
            fun add(tf: Int, tr: Int, promotion: Char? = null) {
                if (!inside(tf, tr)) return
                val target = position.squares[index(tf, tr)]
                if (target == '.' || enemy(p, target)) pseudo += ChessMove(i, index(tf, tr), promotion)
            }
            when (p.lowercaseChar()) {
                'p' -> {
                    val d = if (side) 1 else -1
                    val start = if (side) 1 else 6
                    val last = if (side) 7 else 0
                    val nr = r + d
                    if (inside(f, nr) && position.squares[index(f, nr)] == '.') {
                        if (nr == last) "qrbn".forEach { add(f, nr, if (side) it.uppercaseChar() else it) } else add(f, nr)
                        if (r == start && position.squares[index(f, r + 2 * d)] == '.') add(f, r + 2 * d)
                    }
                    for (df in listOf(-1, 1)) if (inside(f + df, nr)) {
                        val target = position.squares[index(f + df, nr)]
                        val ep = position.enPassant == "${'a' + f + df}${'1' + nr}"
                        if (enemy(p, target) || ep) {
                            if (nr == last) "qrbn".forEach { add(f + df, nr, if (side) it.uppercaseChar() else it) }
                            else pseudo += ChessMove(i, index(f + df, nr))
                        }
                    }
                }
                'n' -> listOf(1 to 2, 2 to 1, -1 to 2, -2 to 1, 1 to -2, 2 to -1, -1 to -2, -2 to -1).forEach { add(f + it.first, r + it.second) }
                'k' -> {
                    for (df in -1..1) for (dr in -1..1) if (df != 0 || dr != 0) add(f + df, r + dr)
                    val home = if (side) 0 else 7
                    val rights = position.castling
                    if (r == home && f == 4 && !isInCheck(position, side)) {
                        val kingSide = if (side) 'K' else 'k'; val queenSide = if (side) 'Q' else 'q'
                        if (kingSide in rights && position.squares[index(5, home)] == '.' && position.squares[index(6, home)] == '.' && position.squares[index(7, home)] == (if (side) 'R' else 'r') &&
                            !isSquareAttacked(position, index(5, home), !side) && !isSquareAttacked(position, index(6, home), !side)) pseudo += ChessMove(i, index(6, home))
                        if (queenSide in rights && position.squares[index(1, home)] == '.' && position.squares[index(2, home)] == '.' && position.squares[index(3, home)] == '.' && position.squares[index(0, home)] == (if (side) 'R' else 'r') &&
                            !isSquareAttacked(position, index(3, home), !side) && !isSquareAttacked(position, index(2, home), !side)) pseudo += ChessMove(i, index(2, home))
                    }
                }
                else -> {
                    val dirs = when (p.lowercaseChar()) {
                        'b' -> listOf(1 to 1, 1 to -1, -1 to 1, -1 to -1)
                        'r' -> listOf(1 to 0, -1 to 0, 0 to 1, 0 to -1)
                        else -> listOf(1 to 1, 1 to -1, -1 to 1, -1 to -1, 1 to 0, -1 to 0, 0 to 1, 0 to -1)
                    }
                    dirs.forEach { (df, dr) -> var tf = f + df; var tr = r + dr
                        while (inside(tf, tr)) { val target = position.squares[index(tf, tr)]; if (target == '.') { pseudo += ChessMove(i, index(tf, tr)) } else { if (enemy(p, target)) pseudo += ChessMove(i, index(tf, tr)); break }; tf += df; tr += dr }
                    }
                }
            }
        }
        return pseudo.filter { move ->
            val next = applyUnchecked(position, move)
            !isInCheck(next, side)
        }
    }

    fun apply(position: ChessPosition, move: ChessMove): ChessPosition {
        require(move in legalMoves(position)) { "Нелегальный ход ${move.uci()}" }
        return applyUnchecked(position, move)
    }

    private fun applyUnchecked(p: ChessPosition, m: ChessMove): ChessPosition {
        val board = p.squares.toMutableList()
        val moving = board[m.from]
        val captured = board[m.to]
        board[m.from] = '.'
        if (moving.lowercaseChar() == 'p' && p.enPassant == squareName(m.to) && captured == '.' && file(m.from) != file(m.to)) {
            board[index(file(m.to), rank(m.to) + if (moving.isUpperCase()) -1 else 1)] = '.'
        }
        board[m.to] = m.promotion ?: moving
        if (moving.lowercaseChar() == 'k' && kotlin.math.abs(m.to - m.from) == 2) {
            val home = rank(m.from); val kingSide = file(m.to) == 6; val rookFrom = index(if (kingSide) 7 else 0, home); val rookTo = index(if (kingSide) 5 else 3, home)
            board[rookTo] = board[rookFrom]; board[rookFrom] = '.'
        }
        var rights = p.castling
        fun remove(c: Char) { rights = rights.replace(c.toString(), "") }
        when (moving) { 'K' -> { remove('K'); remove('Q') }; 'k' -> { remove('k'); remove('q') }; 'R' -> { if (m.from == 56) remove('Q'); if (m.from == 63) remove('K') }; 'r' -> { if (m.from == 0) remove('q'); if (m.from == 7) remove('k') } }
        when (m.to) { 56 -> remove('Q'); 63 -> remove('K'); 0 -> remove('q'); 7 -> remove('k') }
        if (rights.isEmpty()) rights = "-"
        val ep = if (moving.lowercaseChar() == 'p' && kotlin.math.abs(rank(m.to) - rank(m.from)) == 2) squareName(index(file(m.from), (rank(m.to) + rank(m.from)) / 2)) else "-"
        val half = if (moving.lowercaseChar() == 'p' || captured != '.') 0 else p.halfmoveClock + 1
        val nextColor = if (p.activeColor == 'w') 'b' else 'w'
        return ChessPosition(board, nextColor, rights, ep, half, p.fullmoveNumber + if (p.activeColor == 'b') 1 else 0)
    }

    fun isInCheck(p: ChessPosition, whiteSide: Boolean = p.activeColor == 'w'): Boolean {
        val king = if (whiteSide) 'K' else 'k'
        val at = p.squares.indexOf(king)
        return at < 0 || isSquareAttacked(p, at, !whiteSide)
    }

    private fun isSquareAttacked(p: ChessPosition, target: Int, byWhite: Boolean): Boolean {
        val tf = file(target); val tr = rank(target)
        p.squares.forEachIndexed { i, piece ->
            if (piece == '.' || white(piece) != byWhite) return@forEachIndexed
            val f = file(i); val r = rank(i); val df = tf - f; val dr = tr - r
            when (piece.lowercaseChar()) {
                'p' -> if (kotlin.math.abs(df) == 1 && dr == if (byWhite) 1 else -1) return true
                'n' -> if ((kotlin.math.abs(df) == 1 && kotlin.math.abs(dr) == 2) || (kotlin.math.abs(df) == 2 && kotlin.math.abs(dr) == 1)) return true
                'k' -> if (kotlin.math.max(kotlin.math.abs(df), kotlin.math.abs(dr)) == 1) return true
                else -> {
                    val diagonal = kotlin.math.abs(df) == kotlin.math.abs(dr) && df != 0
                    val straight = (df == 0) xor (dr == 0)
                    val compatible = (piece.lowercaseChar() == 'q' && (diagonal || straight)) || (piece.lowercaseChar() == 'b' && diagonal) || (piece.lowercaseChar() == 'r' && straight)
                    if (compatible) {
                        val steps = kotlin.math.max(kotlin.math.abs(df), kotlin.math.abs(dr)); val sf = df.compareTo(0); val sr = dr.compareTo(0)
                        var clear = true
                        for (step in 1 until steps) if (p.squares[index(f + sf * step, r + sr * step)] != '.') { clear = false; break }
                        if (clear) return true
                    }
                }
            }
        }
        return false
    }

    /** Resolves common SAN (including check suffixes, captures, disambiguation and promotions). */
    fun resolveSan(position: ChessPosition, sanRaw: String): ChessMove {
        val san = sanRaw.trim().replace("0-0-0", "O-O-O").replace("0-0", "O-O").replace(Regex("[+#?!]+$"), "")
        val candidates = legalMoves(position)
        val castle = when (san) { "O-O" -> 2; "O-O-O" -> 3; else -> 0 }
        if (castle != 0) return candidates.singleOrNull { kotlin.math.abs(it.to - it.from) == 2 && (if (castle == 2) file(it.to) == 6 else file(it.to) == 2) } ?: error("Нелегальная рокировка: $san")
        val promotion = Regex("=([QRBN])$", RegexOption.IGNORE_CASE).find(san)?.groupValues?.get(1)?.first()?.uppercaseChar()
        val core = san.replace(Regex("=[QRBN]$", RegexOption.IGNORE_CASE), "")
        val piece = core.firstOrNull()?.takeIf { it in "KQRBN" } ?: 'P'
        val body = if (piece == 'P') core else core.drop(1)
        val destMatch = Regex("([a-h][1-8])$").find(body) ?: error("Неизвестная SAN-нотация: $san")
        val dest = squareIndex(destMatch.groupValues[1])
        val captureRequired = 'x' in body
        val prefix = body.dropLast(2).replace("x", "")
        val candidatesFound = candidates.filter { m ->
            val p = position.squares[m.from]
            val isCapture = position.squares[m.to] != '.' || (p.lowercaseChar() == 'p' && position.enPassant == squareName(m.to) && file(m.from) != file(m.to))
            p.uppercaseChar() == piece && m.to == dest && captureRequired == isCapture && (promotion == null || m.promotion?.uppercaseChar() == promotion) &&
                (prefix.none { it in 'a'..'h' } || prefix.any { it == 'a' + file(m.from) }) &&
                (prefix.none { it in '1'..'8' } || prefix.any { it == '1' + rank(m.from) })
        }
        return candidatesFound.singleOrNull() ?: error("Ход неоднозначен или нелегален: $san")
    }
}

fun squareIndex(name: String): Int { require(name.matches(Regex("[a-h][1-8]"))); return (8 - (name[1] - '0')) * 8 + (name[0] - 'a') }
fun squareName(index: Int): String { require(index in 0..63); return "${'a' + index % 8}${'1' + (7 - index / 8)}" }
