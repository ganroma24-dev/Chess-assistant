# Piece classifier dataset

Create one subfolder for each class and place square-crop images inside:

`empty/ P/ N/ B/ R/ Q/ K/ p/ n/ b/ r/ q/ k/`

The `empty` folder contains empty squares; uppercase letters are White pieces and lowercase letters are Black pieces. Each image should show one entire board square, including the square's background. Use many different piece sets, board colors, scaling levels, lighting conditions, and anti-aliasing styles. Keep independent validation screenshots out of the training images. The training script expects at least a useful number of samples in every class.
