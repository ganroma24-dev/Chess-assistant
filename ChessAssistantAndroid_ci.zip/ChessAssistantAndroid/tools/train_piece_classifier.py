#!/usr/bin/env python3
"""Train the Chess Assistant 13-class square classifier and export a TFLite model.

Dataset layout: datasets/pieces/<class>/*.png, where class folders are exactly:
  empty, P, N, B, R, Q, K, p, n, b, r, q, k
Each image must be a crop of ONE complete board square (including its square background),
not a transparent piece icon. Include samples from every board theme/piece set you intend to support.
"""
from pathlib import Path
import tensorflow as tf

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "datasets" / "pieces"
OUT = ROOT / "app" / "src" / "main" / "assets"
CLASSES = ["empty", "P", "N", "B", "R", "Q", "K", "p", "n", "b", "r", "q", "k"]
SIZE = 64

if not all((DATA / name).is_dir() for name in CLASSES):
    missing = [name for name in CLASSES if not (DATA / name).is_dir()]
    raise SystemExit(f"Missing class folders: {missing}; see README for dataset format")

train = tf.keras.utils.image_dataset_from_directory(
    DATA, labels="inferred", label_mode="int", class_names=CLASSES,
    image_size=(SIZE, SIZE), batch_size=32, validation_split=0.2,
    subset="training", seed=42, color_mode="rgb")
valid = tf.keras.utils.image_dataset_from_directory(
    DATA, labels="inferred", label_mode="int", class_names=CLASSES,
    image_size=(SIZE, SIZE), batch_size=32, validation_split=0.2,
    subset="validation", seed=42, color_mode="rgb")
AUTOTUNE = tf.data.AUTOTUNE
train = train.map(lambda x, y: (tf.cast(x, tf.float32) / 255.0, y)).prefetch(AUTOTUNE)
valid = valid.map(lambda x, y: (tf.cast(x, tf.float32) / 255.0, y)).prefetch(AUTOTUNE)

inputs = tf.keras.Input((SIZE, SIZE, 3), batch_size=None, name="square_rgb")
x = tf.keras.layers.RandomRotation(0.04)(inputs)
x = tf.keras.layers.RandomZoom(0.08)(x)
x = tf.keras.layers.Conv2D(24, 3, activation="relu", padding="same")(x)
x = tf.keras.layers.MaxPooling2D()(x)
x = tf.keras.layers.Conv2D(48, 3, activation="relu", padding="same")(x)
x = tf.keras.layers.MaxPooling2D()(x)
x = tf.keras.layers.Conv2D(96, 3, activation="relu", padding="same")(x)
x = tf.keras.layers.GlobalAveragePooling2D()(x)
x = tf.keras.layers.Dropout(0.25)(x)
outputs = tf.keras.layers.Dense(len(CLASSES), activation="softmax", name="piece_class")(x)
model = tf.keras.Model(inputs, outputs)
model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
model.fit(train, validation_data=valid, epochs=30, callbacks=[
    tf.keras.callbacks.EarlyStopping(patience=5, restore_best_weights=True)])

converter = tf.lite.TFLiteConverter.from_keras_model(model)
converter.optimizations = [tf.lite.Optimize.DEFAULT]
tflite = converter.convert()
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "piece_classifier.tflite").write_bytes(tflite)
print(f"Wrote {OUT / 'piece_classifier.tflite'}")
print("Output order:", CLASSES)
