# Chess Assistant 0.3.0 — Android / Kotlin / Jetpack Compose

Native Android study tool. Screen capture is started only after the Android MediaProjection consent dialog. The visible foreground notification and floating overlay remain explicit and user-controlled. Analysis is a manual action for study positions and completed-game review; the app does not provide hidden move assistance during rated online games.

## Implemented in 0.3.0

- Dark blue glass-style Compose UI, calibrated board region, MediaProjection foreground service, and visible overlay.
- In-memory screen-frame processing; screenshots are not written to storage.
- Automatic axis-aligned board candidate detection within the user-selected capture region, using alternating square luminance. The user-calibrated rectangle remains the fallback. Perspective/homography correction is not yet implemented.
- Optional TensorFlow Lite 13-class piece recognition (`empty, P, N, B, R, Q, K, p, n, b, r, q, k`) with batched 64-square inference. Two stable observations are required before the board is accepted.
- Legal move core: legal move generation, check filtering, castling, en-passant, promotion, SAN resolution, and exact board-diff move tracking.
- PGN replay with legality checking, FEN snapshots, and navigation through every half-move.
- Manual Stockfish analysis button for the FEN in the study editor. UCI execution has a time limit and is run off the UI thread.

## Piece model: required before automatic recognition can work

A trained model is intentionally not fabricated or bundled. The app loads `piece_classifier.tflite` from either:

1. `app/src/main/assets/piece_classifier.tflite` (recommended; add the file before building), or
2. the app-private files directory as `piece_classifier.tflite`.

The model input contract is `[batch, 64, 64, 3]` RGB float values normalized to 0..1. Output is `[batch, 13]` scores in this exact order:

`empty, P, N, B, R, Q, K, p, n, b, r, q, k`

Training data must contain full square crops, including the board-square background, from every board theme and piece set that should be supported. Put images in `datasets/pieces/<class>/`. Then install TensorFlow in a Python environment and run:

```bash
python tools/train_piece_classifier.py
```

The script exports `app/src/main/assets/piece_classifier.tflite`. Validate accuracy on board screenshots not present in the training split before relying on recognition. Without the trained model, the app can attempt board-boundary detection but will not identify pieces or reconstruct moves from captured frames.

## Stockfish

The app expects a native Android Stockfish executable at `files/engine/stockfish` in app-private storage and requires executable permission. Use a build for the device ABI (normally `arm64-v8a`) and comply with Stockfish's GPL distribution requirements. Do not use a desktop binary. The source archive does not include a Stockfish binary. Analysis is launched manually from the study-position editor; no overlay best-move output is provided during live online play.

## Build

Open this folder in Android Studio. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35, and min SDK 26. Let Android Studio install the SDK and Gradle components. This archive does not include a Gradle wrapper. The current development environment has `kotlinc` but no Gradle executable or Android SDK, so a full Android APK build has not been performed.

## Current limitations / device validation

- Board detection searches for checkerboard contrast inside the user's selected region; it is not a general-purpose perspective/quad detector and can fail on unusual themes, low contrast, animation, or overlays.
- Piece recognition requires the separately trained TFLite model and must be validated against real target themes. No model weights are included.
- Move tracking starts with the side-to-move value from the saved study FEN; castling rights are unknown from pixels and default to none. The user should synchronize the study position before capture.
- The legal move implementation covers standard chess movement, checks, castling, en-passant and promotion; exotic PGN extensions and Chess960 are not supported.
- Stockfish requires a compatible executable installed locally. Only the UCI adapter and manual UI action are included.
- Android 14/15 MediaProjection lifecycle, overlay permission, rotation, and sustained frame processing still require device testing.

PGN review positions can also be sent to Stockfish manually; the analysis-depth control is available in both the study editor and PGN replay view (8–20 plies).
